#ifndef LINKED_LIST
#define LINKED_LIST
#endif
#include <stdlib.h>
struct LL
{
	int byte;
	int frequency;
	struct LL *next;
};

