#ifndef LINKED_LIST_R 
#define LINKED_LIST_R
#endif 
#include <stdlib.h>
struct LLr {
	int c;
	int run_byte_loc;
	int run_l;
	struct LLr *next;
};
